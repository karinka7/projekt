<?php
    class Banner{
        public $heading;

        function __construct(){
            
        }
        
        function get_heading($Page){
            switch($page){
                case 'index':
                    return $this->heading = "Náš príbeh";
                    break;
                case 'kontakt':
                    return $this->heading = "Kontaktujte nás";
                    break;
                case 'portfolio':
                    return $this->heading = "Galéria";
                    break;
                case 'qna':
                    return $this->heading = "RSVP";
                    break;
            } 
        }

    }
    $Banner = new Banner();
?>
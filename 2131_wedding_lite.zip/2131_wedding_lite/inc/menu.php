<?php
    class Menu{
        public $menu;

        function __construct($menu){
            $this->menu = $menu;
        }
        function get_menu(){
            return $this->menu;
        }
    }
    $Header_menu = new Menu(array("Domovská stránka"=>"index.php",
                                  "Galéria"=>"Galéria.php",
                                  "Napíšte nám"=>"kontaktujte nás.php",
                        ));
    $Footer_menu = new Menu(array("Galéria"=>"Galéria.php",
                                  "Napíšte nám"=>"kontaktujte nás.php",
                        ));
    function print_menu($menu){
        $menu_items = $menu->get_menu();
        foreach($menu_items as $page=>$url){
            echo '<li><a href="'.$url.'">'.$page.'</a></li>';
        }
    }
    
?>
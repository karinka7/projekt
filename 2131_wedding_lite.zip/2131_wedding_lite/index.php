<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Moja stránka</title>

        <!-- CSS FILES -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Amatic+SC:wght@400;700&family=Playfair+Display&display=swap" rel="stylesheet">

        <link href="css/bootstrap.min.css" rel="stylesheet">

        <link href="css/bootstrap-icons.css" rel="stylesheet">

        <link href="css/magnific-popup.css" rel="stylesheet">

        <link href="css/tooplate-wedding-lite.css" rel="stylesheet">
        
<!--

Tooplate 2131 Wedding Lite

https://www.tooplate.com/view/2131-wedding-lite

Free Bootstrap 5 HTML Template

-->
    </head>
    
    <body>

        <section class="preloader">
            <div class="spinner">
                <span class="spinner-rotate">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"/>
                    </svg>
                </span>    
            </div>
        </section>

        <nav class="navbar navbar-expand-lg">
            <div class="container">

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <a href="index.html" class="navbar-brand mx-auto mx-lg-0">
                    <span>Lukáš</span>
                    <i class="bi-heart brand-icon"></i>
                    <span>Xénia</span>
                </a>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_1">Domovská stránka</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_2">Náš príbeh</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_3">Svadba</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_4">Družička a družba</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_5">Portfólio</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_6">Rsvp</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link click-scroll" href="#section_7">Kontakt</a>
                        </li>
                    </ul>
                </div>

            </div>
        </nav>

        <main>

            <section class="hero-section d-flex" id="section_1">
                <div class="hero-container container d-flex flex-column justify-content-end">
                    <div class="row h-100">

                        <div class="col-lg-6 col-12 my-auto">
                            <h2>👋 Dobrý deň, ste pozvaní</h2>

                            <h1 class="text-white hero-title mb-4">Berieme sa</h1>

                            
                            <a href="#section_2" class="custom-link custom-btn btn mt-4">Zistiť viac</a>
                        </div>

                        <div class="col-lg-3 col-12 save-the-date-wrap mt-auto ms-lg-auto">
                            <div class="save-the-date-thumb">
                                <h4 class="save-the-date-title">Dátum Svadby</h4>

                                <div class="save-the-date-body">
                                    <span class="date">22. 05. 2023</span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>


            <?php
            include_once 'partials/manzelia.php';
            ?>

            <section class="the-wedding-section section-bg section-padding" id="section_3">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12">
                            <div class="section-title-wrap mb-5">
                                <h2 class="section-title">Svadba</h2>

                                <div class="section-title-bottom">
                                    <span class="section-title-line"></span>
                                    <i class="section-title-icon bi-heart-fill"></i>
                                    <span class="section-title-line"></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-12 d-flex flex-column mb-4 mb-lg-0 mb-md-0">
                            <div class="image-hover-thumb">
                                <img src="images/dolina_svadba08.jpg" class="img-fluid" alt="">
                            </div>

                            <div class="section-block">
                                <h3 class="my-3">svadobná sála</h3>

                                <p class="mb-2">
                                    <i class="bi-geo-alt me-1"></i>
                                    Rosinská cesta 13, 010 08 Žilina
                                </p>

                                <p>
                                    <i class="bi-clock me-1"></i>
                                    17:30 hod.
                                </p>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-12 d-flex flex-column mb-4 mb-lg-0 mb-md-0">
                            <div class="image-hover-thumb">
                                <img src="images/svadobny_pripitok.jpg" class="img-fluid" alt="">
                            </div>

                            <div class="section-block">
                                <h3 class="my-3">Svadobný obrad</h3>

                                <p class="mb-2">
                                    <i class="bi-geo-alt me-1"></i>
                                    kostol sv Juraja, Iglesia católica de San Jorge en Trnove, Zilina, Trnové, 010 01 Žilina
                                </p>

                                <p>
                                    <i class="bi-clock me-1"></i>
                                    od 16:00 do 17:00 hod.
                                </p>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-12 d-flex flex-column">
                            <img src="images/mapa.jpg" class="img-fluid" alt="">
                            <div class="section-block">
                                <h3 class="my-3">Lokalita</h3>

                                <p class="mb-2">
                                    <i class="bi-geo-alt me-1"></i>
                                    Rosinská cesta 13, 010 08 Žilina
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

            <section class="people-section section-padding" id="section_4">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12">
                            <div class="section-title-wrap mb-5">
                                <h2 class="section-title">Družbovia a družičky</h2>

                                <div class="section-title-bottom">
                                    <span class="section-title-line"></span>
                                    <i class="section-title-icon bi-heart-fill"></i>
                                    <span class="section-title-line"></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-5 col-12 me-auto">
                            <nav>
                                <div class="nav nav-tabs flex-lg-column align-items-baseline" id="nav-tab" role="tablist">
                                    <button class="nav-link active" id="nav-groomsmen-tab" data-bs-toggle="tab" data-bs-target="#nav-groomsmen" type="button" role="tab" aria-controls="nav-groomsmen" aria-selected="true">
                                        <h3>Strana ženícha</h3>
                                    </button>

                                    <button class="nav-link" id="nav-bridesmaid-tab" data-bs-toggle="tab" data-bs-target="#nav-bridesmaid" type="button" role="tab" aria-controls="nav-bridesmaid" aria-selected="false">
                                        <h3>Strana nevesty</h3>
                                    </button>
                                </div>
                            </nav>
                        </div>

                        <div class="col-lg-8 col-md-6 col-12">
                            <div class="tab-content" id="nav-tabContent">

                                <div class="tab-pane fade show active" id="nav-groomsmen" role="tabpanel" aria-labelledby="nav-groomsmen-tab">
                                    <div class="row">
                                       <div class="col-lg-6 col-12">
                                            <div class="people-thumb image-hover-thumb">
                                                <img src="images/people/Bez názvu.jpg" class="people-image img-fluid" alt="">
                                            </div>
                                       </div> 

                                       <div class="col-lg-6 col-12">
                                            <div class="section-block">
                                                <div class="d-flex align-items-center my-3">
                                                    <h4 class="mb-0">Erik</h4>

                                                    <span class="about-tag ms-2">Bratranec</span>
                                                </div>

                                                <p>Erik je bratranec Lukáša.</p>

                                                   <p>Som veľmi rád, že si sa nakoniec rozhodol oženiť.</p>
                                                
                                            </div>
                                       </div> 

                                       <div class="col-lg-6 col-12">
                                            <div class="people-thumb image-hover-thumb">
                                                <img src="images/people/tomas.jpg" class="people-image img-fluid" alt="">
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-12">
                                            <div class="section-block">
                                                <div class="d-flex align-items-center my-3">
                                                    <h4 class="mb-0">Tomáš</h4>

                                                    <span class="about-tag ms-2">Najlepší kamarát</span>
                                                </div>

                                                <p>Tomáš je najlepší kamarát Lukáša.</p>

                                                <p>Gratulujem ti, že si sa rozhodol pre takúto krásnu ženu.</p>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade show" id="nav-bridesmaid" role="tabpanel" aria-labelledby="nav-bridesmaid-tab">
                                    <div class="row">
                                       <div class="col-lg-6 col-12">
                                            <div class="people-thumb image-hover-thumb">
                                                <img src="images/people/brat.jpg" class="people-image img-fluid" alt="">
                                            </div>
                                       </div> 

                                       <div class="col-lg-6 col-12">
                                            <div class="section-block">
                                                <div class="d-flex align-items-center my-3">
                                                    <h4 class="mb-0">Vladimír Greguš</h4>

                                                    <span class="about-tag ms-2">Brat</span>
                                                </div>

                                                <p>Vladimír je brat Xénie.</p>
                                                <p>Som nasmierne rád, že budeš vydatá pani.</p>
                                            </div>
                                       </div> 

                                       <div class="col-lg-6 col-12">
                                            <div class="people-thumb image-hover-thumb">
                                                <img src="images/people/chili.jpg" class="people-image img-fluid" alt="">
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-12">
                                            <div class="section-block">
                                                <div class="d-flex align-items-center my-3">
                                                    <h4 class="mb-0">Chili</h4>

                                                    <span class="about-tag ms-2">Kamarátka</span>
                                                </div>

                                                <p>Chili je kamarátka Xénie.</p>

                                                <p>Gratulujem ti ku svadbe moja krásna.</p>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </section>

            <section class="gallery-section section-bg section-padding" id="section_5">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12">
                            <div class="section-title-wrap mb-5">
                                <h2 class="section-title">Portfólio</h2>

                                <div class="section-title-bottom">
                                    <span class="section-title-line"></span>
                                    <i class="section-title-icon bi-heart-fill"></i>
                                    <span class="section-title-line"></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-12">
                            <div class="gallery-thumb image-hover-thumb">
                                <a href="images/gallery/svadba.jpg" class="popup-image">
                                    <img src="images/gallery/svadba.jpg" class="gallery-image img-fluid" alt="">
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-4 col-12 d-flex flex-column">
                            <div class="gallery-thumb gallery-thumb-small image-hover-thumb">
                                <a href="images/gallery/2.jpg" class="popup-image">
                                    <img src="images/gallery/2.jpg" class="gallery-image img-fluid" alt="">
                                </a>
                            </div>

                            <div class="gallery-thumb gallery-thumb-small image-hover-thumb">
                                <a href="images/gallery/couple.jpg" class="popup-image">
                                    <img src="images/gallery/couple.jpg" class="gallery-image img-fluid" alt="">
                                </a>
                            </div>
                        </div>
                        

                        
                            
                <section class="rsvp-section section-padding" id="section_6">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-8 col-12 mx-auto">
                            <div class="rsvp-form-wrap">
                                <div class="section-title-wrap mb-5">
                                    <h2 class="section-title">Rsvp</h2>

                                    <div class="section-title-bottom">
                                        <span class="section-title-line"></span>
                                        <i class="section-title-icon bi-heart-fill"></i>
                                        <span class="section-title-line"></span>
                                    </div>
                                </div>

                                <h5 class="mb-4">Zúčastníte sa? <span class="text-muted">Rezervujte si svoje miesto do 15. 05. 2023</span></h5>

                                <form class="custom-form rsvp-form" role="form">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-6 col-12">
                                            <input type="text" name="name" id="name" class="form-control" placeholder="Krstné meno*" required="">
                                        </div>

                                        <div class="col-lg-4 col-md-6 col-12"> 
                                            <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="Svoj Email*" required="">
                                        </div>

                                        <div class="col-lg-4 col-12"> 
                                            <select name="guests" class="form-select" id="guests" aria-label="Guests">
                                                <option selected>Počet hostí</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                            </select>
                                        </div>

                                        <div class="col-lg-12 col-12">
                                            <textarea class="form-control" id="message" name="message" placeholder="Správa (nepovinná)" rows="5"></textarea>
                                        </div>
                                        
                                        <div class="col-lg-3 col-5 mx-auto">
                                            <button type="submit" class="form-control">Poslať pozvánku</button>
                                        </div>
                                        <p>Údaje označené * sú povinné</p>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

            <section class="contact-section section-bg section-padding" id="section_7">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12">
                            <div class="section-title-wrap mb-5">
                                <h2 class="section-title">Kontakt</h2>

                                <div class="section-title-bottom">
                                    <span class="section-title-line"></span>
                                    <i class="section-title-icon bi-heart-fill"></i>
                                    <span class="section-title-line"></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 col-12">
                            <h4 class="mb-4">Navštívte nás</h4>

                            <p>Rosinská cesta 13, 010 08 Žilina</p>
                        </div>

                        <div class="col-lg-4 col-md-6 col-12 my-4 my-lg-0 my-md-0">
                            <h4 class="mb-4">Kontaktné informácie</h4>

                            <p class="mb-2">
                                <a href="mailto:hello@company.com">
                                    karinteddyzilic@gmail.com
                                </a>
                            </p>

                            <p>
                                <a href="tel: 090-080-0760">
                                    0902 756 662
                                </a>
                            </p>
                        </div>

                        <div class="col-lg-4 col-md-6 col-12">
                            <h4 class="mb-4">Sociálne siete</h4>

                            <ul class="social-icon">
                                <li class="social-icon-item"><a href="#" class="social-icon-link bi-twitter"></a></li>

                                <li class="social-icon-item"><a href="#" class="social-icon-link bi-instagram"></a></li>

                                <li class="social-icon-item"><a href="#" class="social-icon-link bi-whatsapp"></a></li>

                                <li class="social-icon-item"><a href="https://fb.com/tooplate" target="_blank" class="social-icon-link bi-facebook"></a></li>
                            </ul>

                            <p class="copyright-text mt-3 mb-0">Copyright © 2023 Wedding Lite Co., Ltd. 
                            <br> Dizajn: <a href="https://www.tooplate.com" target="_parent">Karin Hollá</a></p>
                        </div>

                    </div>
                </div>
            </section>

        </main>

        <footer class="site-footer">
            <div class="container">
                <div class="row">

                    <div class="col-lg-3 col-12 mx-auto">
                        <a href="index.html" class="navbar-brand mx-auto mx-lg-0">
                            <span>Lukáš</span>
                            <i class="bi-heart brand-icon"></i>
                            <span>Xénia</span>
                        </a>
                    </div>

                </div>
            </div>
        </footer>

        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/click-scroll.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/magnific-popup-options.js"></script>
        <script src="js/custom.js"></script>

    </body>
</html>



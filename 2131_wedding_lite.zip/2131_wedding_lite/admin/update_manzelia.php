<?php
include_once "../functions.php";
use main\body;
if(isset($_POST['submit'])) {
    $bodyObj = new body();
    $update = $bodyObj->updatemanzelia_item(
        $_POST['id'],
        $_POST['meno'],
        $_POST['priezvisko'],
        $_POST['text']);
    if($update) {
        header('Location: manzelia_list.php?status=2');
    } else {
        header('Location: manzelia_list.php?status=3');
    }
}
else {
    header('Location: manzelia_list.php');
}
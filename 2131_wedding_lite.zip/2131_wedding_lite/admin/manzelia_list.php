<?php
include_once "../functions.php";
use main\body;
$bodyObj = new body();
$manzel_items = $bodyObj->get_manzel();

include_once "html_menu_manzelia.php";
if(isset($_GET['status']) && $_GET['status'] == 2) {
    echo "<strong>Údaje úspešne aktualizované</strong><br><br>";
} elseif (isset($_GET['status']) && $_GET['status'] == 3) {
    echo "<strong>Údaje sa nepodarilo aktualizovať</strong><br><br>";
}

foreach ($manzel_items as $key=>$manzel_item) {
    echo "<li>ID: ". $manzel_item['id'] . ", Meno: " . $manzel_item['meno'] . ", Priezvisko: " . $manzel_item['priezvisko']. ", Text: " .$manzel_item['text'].
        '<a href="delete_manzelia.php?id='.$manzel_item['id'].'">Vymazať</a> /
             <a href="update_manzelia_form.php?id='.$manzel_item['id'].'">Aktualizovať</a>
            </li>';
}
?>
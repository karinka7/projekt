<?php
include_once "../functions.php";

use main\body;

$bodyObj = new body();
$manzelia_item = $bodyObj->getmanzelia_item($_GET['id']);


include_once "html_menu_manzelia.php";
?>
<form action="update_manzelia.php" method="post">
    Meno:<br>
    <input type="text" name="meno" placeholder="Meno" value="<?php echo $manzelia_item['meno']; ?>"><br>
    Priezvisko:<br>
    <input type="text" name="priezvisko" placeholder="Priezvisko" value="<?php echo $manzelia_item['priezvisko']; ?>"><br>
    Text tu chyba:<br>
    <input type="text" name="text" placeholder="text" value="<?php echo $manzelia_item['text']; ?>"><br>
    <input type="hidden" name="id" value="<?php echo $manzelia_item['id']; ?>">
    <input type="submit" name="submit" value="Update">
</form>

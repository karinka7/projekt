<?php
include_once "../functions.php";
use main\body;
$bodyObj = new body();
if (isset($_GET['id'])) {
    $delete = $bodyObj->delete_manzeliaItem($_GET['id']);
    if ($delete) {
        header('Location: manzelia_list.php');
    } else {
        echo "Chyba";
    }
} else {
    header('Location: manzelia_list.php');
}
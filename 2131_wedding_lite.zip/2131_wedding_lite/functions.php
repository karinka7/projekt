<?php

namespace main;

use \PDO;

class body
{


    private string $hostname = "localhost";
    private int $port = 3306;
    private string $username = "root";
    private string $password = "";
    private string $dbName = "sj2023";
    private $connection;

    public function __construct(string $host = "", int $port = 3306, string $user = "", string $pass = "", string $dbName = "")
    {
        if (!empty($host)) {
            $this->hostname = $host;
        }

        if (!empty($port)) {
            $this->port = $port;
        }

        if (!empty($user)) {
            $this->username = $user;
        }

        if (!empty($pass)) {
            $this->password = $pass;
        }

        if (!empty($dbName)) {
            $this->dbName = $dbName;
        }

        try {

            $this->connection = new PDO("mysql:charset=utf8;host=" . $this->hostname . ";dbname=" . $this->dbName . ";port=" . $this->port, $this->username, $this->password);
        } catch (\Exception $exception) {
            echo $exception->getMessage();
            die();
        }
    }

    public function get_manzel(): array
    {

        try {
            $sql = "SELECT * FROM manzelia";
            $query = $this->connection->query($sql);
            $manzelia_items = $query->fetchAll(PDO::FETCH_ASSOC);
        } catch (\Exception $exception) {
            $manzelia_items = [0 => ['id' => 1, 'meno' => 'Lukaš', 'priezvisko' => 'Stanislav', 'text' => 'Veľmi sa mi páči jej talentované úspechy, ktoré si dosiahla.']
                , 1 => ['id' => 2, 'meno' => 'Xénia', 'priezvisko' => 'Gregušová', 'text' => 'Xénia je úžasná.']];
        }


        return $manzelia_items;
    }

    public function printmanzelia(array $manzelia_items)
    {
        foreach ($manzelia_items as $key => $item) {
            echo '<div class="col-lg-3 col-12">
                            <div class="image-hover-thumb">
                                <img src="images/manzelia/manzel' . $item['id'] . '.jpg" class="about-image img-fluid" alt="">
                            </div>
                        </div>

                        <div class="col-lg-3 col-12">
                            <div class="about-info-wrap d-flex flex-column">
 
                                    <h4>' . $item['meno'] . " " . $item['priezvisko'] . '</h4>

                                  
                                <p>' . $item['text'] . '</p>

                              
                            </div>
                        </div>';
        }
    }

    public function insertmanzelia_Item(int $id, string $meno, string $priezvisko, string $text): bool
    {
        $insert = false;
        $sql = "INSERT INTO manzelia(id,meno,priezvisko,text) VALUES ('" . $id . "','" . $meno . "','" . $priezvisko . "','" . $text . "')";
        try {
            $statement = $this->connection->prepare($sql);
            $insert = $statement->execute();

        } catch (\Exception $exception) {
            echo "Nebolo možné vložiť. Chyba: " . $exception->getMessage();
        }
        return $insert;
    }

    public function delete_manzeliaItem(int $id): bool
    {
        $delete = false;
        $sql = "DELETE FROM manzelia WHERE id = " . $id;

        try {
            $statment = $this->connection->prepare($sql);
            $delete = $statment->execute();
        } catch (\Exception $exception) {
            echo "Nebolo možné odstrániť. Chyba: " . $exception->getMessage();
        }

        return $delete;
    }


    public function getmanzelia_item(int $id): array
    {
        {
            try {
                $sql = "SELECT * FROM manzelia WHERE id = " . $id;
                $query = $this->connection->query($sql);
                $data = $query->fetch(\PDO::FETCH_ASSOC);


            } catch (\Exception $exception) {
                echo "Chyba: " . $exception->getMessage();
            }

            return $data;

        }
    }

    public function updatemanzelia_item(int $id, string $meno, string $priezvisko, string $text): bool
    {
        try {
            $sql = "UPDATE manzelia SET meno = :meno, priezvisko = :priezvisko, text = :text WHERE id = :id";
            $statement = $this->connection->prepare($sql);
            $update = $statement->execute([
                'meno' => $meno,
                'priezvisko' => $priezvisko,
                'text' => $text,
                'id' => $id,
            ]);
        } catch (\Exception $exception) {
            $update = false;

        }
        return $update;
    }
}
        
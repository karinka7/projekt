<form id="contact" action="inc/contact/insert.php" method="post">
            <input type="text" placeholder="Krstné meno" id ="contact_name" name = "contact_name" required><br>
            <input type="email" placeholder="Svoj email" id="contact_email" name ="contact_email" required><br>
            <select name="guests" class="form-select" id="guests" aria-label="Guests">
                                                <option selected>Počet hostí</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                            </select>
            <textarea placeholder="Správa" id="contact_message" name="contact_message" ></textarea><br>
            <input type="submit" value="Odoslať" name="contact_us">
</form>
<div id="error" class="text-red">
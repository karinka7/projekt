<?php
include_once "functions.php";
use main\body;
$bodyObj = new body();
$manzelia_items = $bodyObj->get_manzel();

?>

<section class="about-section section-padding" id="section_2">
    <div class="container">
        <div class="row">

            <div class="col-lg-12 col-12">
                <div class="section-title-wrap mb-5">
                    <h2 class="section-title">Náš príbeh</h2>

                    <div class="section-title-bottom">
                        <span class="section-title-line"></span>
                        <i class="section-title-icon bi-heart-fill"></i>
                        <span class="section-title-line"></span>
                    </div>
                </div>
            </div>


            <?php
            $bodyObj->printmanzelia($manzelia_items);
            ?>


        </div>
    </div>
</section>

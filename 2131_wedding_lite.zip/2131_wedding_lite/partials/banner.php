<section class="banner">
    <div class="container text-white">
        <h1>
            <?php 
            //echo page_name();
             $page = $page ->get_file_name();
             echo $banner->get_heading($page);
            ?>
        </h1>
    </div>
</section>